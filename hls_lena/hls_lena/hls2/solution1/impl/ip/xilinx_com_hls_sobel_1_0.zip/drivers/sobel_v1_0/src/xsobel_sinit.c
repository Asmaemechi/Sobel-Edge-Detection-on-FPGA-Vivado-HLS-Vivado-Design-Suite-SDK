// ==============================================================
// File generated on Fri May 31 10:17:08 +0200 2019
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xsobel.h"

extern XSobel_Config XSobel_ConfigTable[];

XSobel_Config *XSobel_LookupConfig(u16 DeviceId) {
	XSobel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSOBEL_NUM_INSTANCES; Index++) {
		if (XSobel_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSobel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSobel_Initialize(XSobel *InstancePtr, u16 DeviceId) {
	XSobel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSobel_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSobel_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

